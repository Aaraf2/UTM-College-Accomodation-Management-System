
function visitPage(file){
        window.location=file;
    }